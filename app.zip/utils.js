console.log("debut")
let ch = "salut"
let somme = (a,b)=>a+b
module.exports = {
    chaine : ch,
    sum : somme
}
console.log("fin")