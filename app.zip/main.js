let obj = require("./utils.js")
console.log(obj.chaine)
console.log(obj.sum(3,6))